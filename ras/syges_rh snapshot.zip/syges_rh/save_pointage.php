 <?php
    include("first.php");
    include('php/navbar_links.php');
    include("php/db.php")
?>

<?php

if($_POST)
{               


        /*--------------------------------- ETAT HOLIDAY -------------------------------------*/
        // $id = $_POST['id_personnel'];
        $nom= $_POST['name'];
        $arrved_time = $_POST['arrved_time'];
        $date_day = $_POST['date_day'];
        $end_time = $_POST['end_time'];
;

        // echo $nom.'</br>';
        // echo $type_conger.'</br>';
        // echo $start_time.'</br>';
        // echo $end_time.'</br>';
        // echo $motif.'</br>';

        /*--------------------------------- SAVE DATA HOLIDAY ---------------------------*/

        $query1 = " INSERT INTO pointage (name,date_day,arrived_time,end_time) 
        VALUES 
        (:name,:date_day,:arrived_time,:end_time)";

        $sql1 = $db->prepare($query1);

             // Bind parameters to statement
            $sql1->bindParam(':name', $name);
            $sql1->bindParam(':date_day', $date_day);
            $sql1->bindParam(':arrived_time', $arrived_time);
            $sql1->bindParam(':end_time', $end_time);
            $sql1->execute();



                                    if($sql1)
                                    {
                                        ?>
                                        <script>
                                            alert('Pointage a été bien enregistrée.');
                                                 window.location.href='<?=$activite['option3_link']?>';
                                        </script>
                                        <?php
                                    }

                                    else
                                    {       
                                      ?>
                                        <script>
                                            alert('Pointage is failed ...');
                                            window.location.href='<?=$activite['option3_link']?>';
                                        </script>
                                        <?php
                                       
                                    }


}
?>
